﻿namespace MovieStoreMvc.Models.ViewModels.Adminstration
{
    public class RolesCheckedViewModel
    {
        public string Role { get; set; }
        public bool isSelected { get; set; }
    }
}
