﻿namespace MovieStoreMvc.Models.ViewModels.Adminstration
{
    public class RoleViewModel
	{
		public string? Id { get; set; }
		public string RoleName { get; set; }
	}
}
